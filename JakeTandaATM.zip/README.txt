Jake Tanda's ATM Project
CSCI 293
Spring 2019

Possible logins:
NUM	PIN
54123	7890
16423	7621
14779	2355
48621	1556
56541	1562
65441	8710
87452	5418
65412	1555
84462	8544
65416	9842
95841	3524

Can view balance, past 5 transactions and their dates, and withdraw funds.
All information is stored in accounts.xlsx